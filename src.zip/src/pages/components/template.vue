<template>
    <view class="template">

    </view>
</template>
<script>
    export default {
        data(){
            return{

            }
        }
    }
</script>
<style type="text/scss" lang="scss" scoped>
    .template{

    }
</style>
